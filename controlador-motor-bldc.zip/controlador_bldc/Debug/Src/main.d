Src/main.o: ../Src/main.c ../Inc/bldc.h ../Inc/fpu.h ../Inc/uart2.h \
 ../Inc/timer2.h ../Inc/systick.h
../Inc/bldc.h:
../Inc/fpu.h:
../Inc/uart2.h:
../Inc/timer2.h:
../Inc/systick.h:
