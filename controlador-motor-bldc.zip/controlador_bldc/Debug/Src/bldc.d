Src/bldc.o: ../Src/bldc.c ../Inc/uart2.h ../Inc/systick.h ../Inc/timer2.h
../Inc/uart2.h:
../Inc/systick.h:
../Inc/timer2.h:
