#include <stdint.h>
#include <stdio.h>
#include "stm32f446xx.h"
#include <systick.h>
#define enableGPIOA (1U<<0)
#define USART2EN (1U<<17)
#define APB1CLK 16000000 //considerando o SYSTCLK sem prescaler
#define TE (1U<<3)
#define RE (1U<<2)
#define UE (1U<<13)
#define TXE (1U<<7)
#define RXNE (1U<<5)
#define BUFFER_SIZE 100

char uart2Buffer[BUFFER_SIZE]; // Buffer para armazenar a string lida
uint32_t uart2Pos = 0;         // Para armazenar o índice atual do buffer


void uart2RxTxIni(uint32_t baudRate, uint32_t clkPerif)
{
	uint16_t uartDiv;
	RCC->AHB1ENR |= enableGPIOA;                //Habilitando o clock GPIOA
	GPIOA->MODER |= (1U<<5);                    //PA2 como F. Alternativa
	GPIOA->MODER &= ~(1U<<4);                   //PA2 como F. Alternativa
	GPIOA->AFR[0] |= (1U<<8)|(1U<<9)|(1U<<10);  //AF7
	GPIOA->AFR[0] &= ~(1U<<11);                 //AF7
	RCC->APB1ENR |= USART2EN;                   //Habilitando o clock da Usart
	GPIOA->MODER |= (1U<<7);                    //PA3 como F. Alternativa
	GPIOA->MODER &= ~(1U<<6);                   //PA3 como F. Alternativa
	GPIOA->AFR[0] |= (1U<<14)|(1U<<13)|(1U<<12);//AF7
	GPIOA->AFR[0] &= ~(1U<<15);                 //AF7
	//Cálculo do valor da uartDiv para impor o baud
	uartDiv = (clkPerif + (baudRate/2))/baudRate;
	USART2->BRR = uartDiv;
	USART2->CR1 |= TE;
	USART2->CR1 |= RE;
	USART2->CR1 |= UE;
}
void uart2Write(int ch)
{
	//Aguarda para o DATA register ficar vazio
	while(!(USART2->SR & TXE))
	{
		//Fica retido aqui enquanto for falso. DR não vazio
	}
	USART2->DR = (ch &0xFF);
}
char uart2Read(void)
{
	while(!(USART2->SR & RXNE))
	{
		// Aguarda até que os dados estejam prontos para serem lidos
		/*Fica retido aqui enquanto for falso
		Se o RXNE for zero, o resultado AND é falso, o complemento é 1.
		Logo, fica parado dentro do while (1). Quando o valor de RXNE for 1, os dados estão prontos para serem lidos. Logo, vai sair do laço e transmitir.
		0: Data is not received
		1: Received data is ready to be read
		*/
	}
	return (USART2->DR & 0xFF); // Retorna o caractere lido
}

char* uart2ReadString(void)
{
	char ch;
	uart2Pos = 0;

	do {
		ch = uart2Read();

		// Backspace handling
		if (ch == 0x08 || ch == 0x7F) { // Backspace or Delete
			if (uart2Pos > 0) {
				uart2Pos--;
				// Echo backspace: space + backspace
				uart2Write(0x08);
				uart2Write(' ');
				uart2Write(0x08);
			}
			continue;
		}

		// Echo do caractere
		uart2Write(ch);

		// Final da string no Enter ou newline
		if (ch == '\r' || ch == '\n') {
			break;
		}

		// Adicionar ao buffer se houver espaço
		if (uart2Pos < BUFFER_SIZE - 1) {
			uart2Buffer[uart2Pos++] = ch;
		}

	} while (uart2Pos < BUFFER_SIZE - 1);

	uart2Buffer[uart2Pos] = '\0';
	return uart2Buffer;
}


int __io_putchar (int ch)
{
	uart2Write(ch);
	return ch;
}

int uart2StringTam(char * str)
{
	int tam = 0;
	while(str[tam] != '\0'){
		tam++;
	}
	return tam;
}

int uart2CompareString(char * str1, char * str2)
{
	int tam1 = uart2StringTam(str1), tam2 = uart2StringTam(str2);

	if(tam1 != tam2) return 0;

	int pos = 0;
	while((str1[pos] == str2[pos]) && pos < tam1){
		printf("Comparando %c e %c\r\n", str1[pos], str2[pos]);
		pos++;
	}

	if(pos == tam1) return 1;
	else return 0;

}
