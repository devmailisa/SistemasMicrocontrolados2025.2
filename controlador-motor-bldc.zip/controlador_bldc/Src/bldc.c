#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <uart2.h>

#include <systick.h>
#include <timer2.h>

uint8_t dCMin = 50;
uint8_t dCMax = 100;

//FUNÇÃO PARA TESTAR DUTY MÁXIMO E DUTY MÍNIMO
void testandoDuty(void)
{
	uint8_t init = 50, fim = 55;
	char resp1 = 'N', resp2 = 'N';
	do
	{
		printf("\r\nTestando valores entre %d e %d...\r\n", init, fim);

		for(int i = init; i <= fim; i++){
			setDuty(i);
			delayMs(500);
		}

		if(resp1 != 'S'){
			printf("O motor rodou? (S/N) \r\n");
			resp1 = uart2Read();
			if(resp1 == 'S')
			{
				char r;
				printf("\r\nReiniciando os testes com o intervalo...\r\n");
				for(int i = init; i <= fim; i++){
					setDuty(i);
					printf("\r\nEh com %d?\r\n", i);
					r = uart2Read();
					if(r == 'S'){
						init = i;
						break;
					}
				}

			}else{
				init = fim;
				fim += 5;
			}
		} else if(resp2 != 'S'){
			printf("O motor parou de rodar? (S/N) \r\n");
			resp2 = uart2Read();
			if(resp2 == 'S')
			{
				char r;
				printf("\r\nReiniciando os testes com o intervalo...\r\n");
				for(int i = init; i <= fim; i++){
					setDuty(i);
					printf("\r\nEh com %d?\r\n", i);
					r = uart2Read();
					if(r == 'S'){
						fim = i;
						break;
					}
				}

			}else{
				init = fim;
				fim += 5;
			}
		}

	} while(resp1 != 'S' || resp2 != 'S');

	dCMax = fim;
	dCMin = init;
}

void calibrarMotor(void)
{
	setDuty(dCMax);
	delayMs(3000);
	setDuty(dCMin);
	delayMs(2000);
}

//FUNÇÃO PARA ALTERAR A AMPLITUDADE DA RAMPA
int set_step(uint32_t * step, uint32_t new_step)
{
	if(new_step > 0 && new_step < 11){
		*step = new_step;
		return 1;
	}

	return 0;
}

//FUNÇÃO PARA ALTERAR O DELAY ENTRE O ENVIO DO SINAL
void set_hold(uint32_t * delay, uint8_t new_delay)
{
	*delay = new_delay;
}

//GERANDO PULSO DE THROTTLE - ACELERADOR
int thr(uint32_t en, uint32_t *dcAtual, uint32_t * delay, uint32_t * step)
{
    if(en < 0 || en > 100) return 0;

    uint32_t dc;
    float passo;
    passo = (dCMax - dCMin)/99.0;

    //printf("passo: %f\r\n", passo);
    dc = dCMin + passo*(en - 1); //COMPARADOR
    //printf("dc: %d\r\n", dc);

    if(*dcAtual > dc)
    {
        while(*dcAtual != dc)
        {
            uint32_t diff = *dcAtual - dc;
            if(diff >= *step)
            {
                *dcAtual -= *step;
            } else
            {
                *dcAtual -= diff;
            }

            delayMs(*delay);
            setDuty(*dcAtual);
        }

    } else if(*dcAtual < dc)
    {
        while(*dcAtual != dc)
        {
            uint32_t diff = dc - *dcAtual;
            if(diff >= *step)
            {
                *dcAtual += *step;
            } else
            {
                *dcAtual += diff;
            }

            delayMs(*delay);
            setDuty(*dcAtual);
        }
    }


    //printf("dcAtual: %d\r\n", *dcAtual);

    return 1;
}

void help(void)
{
	printf("OLÁ, SEJA BEM-VINDO AO CONTROLADOR DO MOTOR BLDC!\r\n");
	printf("\r\n");
	printf("HELP - LISTA OS COMANDOS\r\n");
	printf("ARM - ATIVA O MOTOR\r\n");
	printf("DISARM - DESATIVA O MOTOR\r\n");
	printf("THR x - ALTERAR A VELOCIDADE DE ROTAÇÃO DO MOTOR EM [0, 100]\r\n");
	printf("SET STEP=x - ALTERA O PASSO DA RAMPA NO INTERVALO [1, 10] \r\n");
	printf("SET HOLD=xx - INTERVALO ENTRE OS PULSOS DA RAMPA\r\n");
	printf("STATUS - IMPRIME O STATUS GERAL DO MOTOR\r\n");
}


//FUNÇÃO PARA VALIDAR MENU DA UART2
int check_in_with_value(char *entrada, char *func, uint32_t *val) {
    char *resto;
    char *ptr = strstr(entrada, func);

    if (ptr != NULL) {
        resto = ptr + strlen(func);
    } else {
        //printf("Substring não encontrada.\r\n");
        return 0;
    }

    char *endptr;
    *val = strtol(resto, &endptr, 10);

    if (*endptr == '\0') {
        printf("Valor: %d\r\n", *val);
        return 1;
    } else {
        printf("Erro na conversão: caracteres não numéricos encontrados\r\n");
        return 0;
    }
}

//VALIDANDO ENTRADAS APENAS COM STRING
int check_in(char * entrada, char * func) {
    return uart2CompareString(entrada, func);
}


