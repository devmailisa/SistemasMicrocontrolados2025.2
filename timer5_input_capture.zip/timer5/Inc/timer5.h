/*
 * timer5.h
 *
 *  Created on: Jan 17, 2026
 *      Author: Isabelle
 */

#ifndef TIMER5_H_
#define TIMER5_H_

#define CC2IF (1U<<2)

void pa1InputCapture(void);

#endif /* TIMER5_H_ */
