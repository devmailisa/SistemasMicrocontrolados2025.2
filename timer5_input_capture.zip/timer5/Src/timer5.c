/* Disciplina: Sistemas Microcontrolados
 * Timer 5 - Modo Input Capture
 * timer5.c
 * Aluna: Isabelle Medeiros
 */

#include <stm32f446xx.h>
#include <stdint.h>

#define APB1CLK			16000000
#define TIMER5EN		(1U<<3)
#define ARR_VALUE_MS	1000
#define ARR_VALUE_US	2
#define UG				(1U<<0)
#define UIF				(1U<<0)
#define CEN				(1U<<0)
#define enableGPIOA		(1U<<0)

void pa1InputCapture(void){

	//GPIOA
	RCC->AHB1ENR |= enableGPIOA;
	GPIOA->MODER |= (1U<<3);
	GPIOA->MODER &= ~(1U<<2);
	GPIOA->AFR[0] |= (1U<<5);

	//Timer 5
	RCC->APB1ENR |= TIMER5EN;
	TIM5->CR1 |= (1U<<0);
	TIM5->PSC = 16 - 1;
	TIM5->EGR |= UG;
	TIM5->CCMR1 |= (1U<<8);
	TIM5->CCER |= (1U<<4);
	TIM2->CR1 |= (1U<<0);
}


