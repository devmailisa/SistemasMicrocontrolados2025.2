#include "stm32f446xx.h"
#include <stdint.h>
#include <uart2.h>
#include <stdio.h>
#include <fpu.h>
#include <timer5.h>
#include <pwm.h>
#include <systick.h>

#define baudRate   115200
#define APB1CLK   16000000

#define PSC 160-1
#define ARR 100-1

uint32_t t1=0, t2=0, intervalo=0;

int main(void) {
   uart2RxTxIni(baudRate , APB1CLK);
   fpuEnable();
   pa1InputCapture();
   configCenterAlignedMode1(ARR, PSC);
   while (1) {
	   TIM5->SR = 0;
	   while(!(TIM5->SR & CC2IF))
	   {

	   }
	   t1 = TIM5->CCR2;
	   while(!(TIM5->SR & CC2IF))
	   {

	   }
	   uint32_t t2 = TIM5->CCR2;
	   if(t2 >= t1) intervalo = t2 - t1;
	   else intervalo = (0xFFFFFFFF - t1 + t2 + 1);

	   printf("T de %ld\r\n", intervalo);
	   delayMs(2000);
   }
}
