#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include <systick.h>
#include <timer2.h>

#define dCMin 53
#define dCMax 118

//FUNÇÃO PARA ALTERAR A AMPLITUDADE DA RAMPA
int set_step(uint32_t * step, uint32_t new_step)
{
	if(new_step > 0 && new_step < 11){
		*step = new_step;
		return 1;
	}

	return 0;
}

//FUNÇÃO PARA ALTERAR O DELAY ENTRE O ENVIO DO SINAL
void set_hold(uint32_t * delay, uint8_t new_delay)
{
	*delay = new_delay;
}

//GERANDO PULSO DE THROTTLE - ACELERADOR
int thr(uint32_t en, uint32_t *dcAtual, uint32_t * delay, uint32_t * step)
{
    if(en < 0 || en > 100) return 0;

    uint32_t dc;
    float passo;
    passo = (dCMax - dCMin)/99.0;

    //printf("passo: %f\r\n", passo);
    dc = dCMin + passo*(en - 1); //COMPARADOR
    //printf("dc: %d\r\n", dc);

    if(*dcAtual > dc)
    {
        while(*dcAtual != dc)
        {
            uint32_t diff = *dcAtual - dc;
            if(diff >= *step)
            {
                *dcAtual -= *step;
            } else
            {
                *dcAtual -= diff;
            }

            delayMs(*delay);
        }

    } else if(*dcAtual < dc)
    {
        while(*dcAtual != dc)
        {
            uint32_t diff = dc - *dcAtual;
            if(diff >= *step)
            {
                *dcAtual += *step;
            } else
            {
                *dcAtual += diff;
            }

            delayMs(*delay);
        }
    }

    //printf("dcAtual: %d\r\n", *dcAtual);

    return 1;
}

void help(void)
{
	printf("======================================================\r\n");
	printf("OLÁ, SEJA BEM-VINDO AO CONTROLADOR DO MOTOR BLDC!\r\n");
	printf("======================================================\r\n");
	printf("COMANDOS:\r\n");
	printf("'HELP' -- LISTA OS PRINCIPAIS COMANDOS.\r\n");
	printf("'ARM' -- USADO PARA ATIVAR O MOTOR.\r\n");
	printf("'DISARM' -- USADO PARA DESATIVAR O MOTOR.\r\n");
	printf("'THR x' -- ENVIA UM COMANDO PARA ALTERAR A ROTAÇÃO DO MOTOR. x DEVE SER UM VALOR NO INTERVALO DE [0, 100].\r\n");
	printf("'SET STEP=x' -- ALTERA O PASSO DA RAMPA. x DEVE ESTAR NO INTERVALO [1, 10] \r\n");
	printf("'SET HOLD=xx' -- INTERVALO ENTRE OS PULSOS DA RAMPA.\r\n");
	printf("'STATUS' -- IMPRIME O STATUS GERAL DO MOTOR COMO VALOR DE THROTTLE, CARACTERÍSTICAS DA RAMPA, PULSO MÁXIMO E MÍNIMO, ETC\r\n");
}


//FUNÇÃO PARA VALIDAR MENU DA UART2
int check_in_with_value(char *entrada, char *func, uint32_t *val) {
    int final_func = strlen(func);

    if (strncmp(entrada, func, final_func) != 0) {
        return 0;
    }

    int digitos = 0;
    char num[4];  // Para armazenar até 3 dígitos + '\0'
    int i = final_func;
    while (isdigit(entrada[i])) {
        num[digitos] = entrada[i];
        digitos++;
        i++;

        // Garantir que não ultrapasse 10 dígitos
        if (digitos > 10) {
            return 0;
        }
    }

    if (digitos == 0) return 0;  // Se não foi lido nenhum dígito

    num[digitos] = '\0';  // Garantir que a string seja corretamente terminada

    if (entrada[i] != '\0') {  // Verifica se há caracteres extras após o número
        return 0;
    }

    // Converte a string num para uint32_t com verificação
    long int temp_val = strtol(num, NULL, 10);
    if (temp_val < 0 || temp_val > UINT32_MAX) {
        return 0;  // Valor fora do intervalo de uint32_t
    }
    *val = (uint32_t)temp_val;

    return 1;
}

//VALIDANDO ENTRADAS APENAS COM STRING
int check_in(char * entrada, char * func) {
    return !strcmp(entrada, func);
}


