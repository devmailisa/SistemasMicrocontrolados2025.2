/*
 * systick.h
 *
 *  Created on: Oct 2, 2025
 *      Author: professor
 */

#ifndef SYSTICK_H_
#define SYSTICK_H_

void delayMs(uint32_t delay);

#endif /* SYSTICK_H_ */
