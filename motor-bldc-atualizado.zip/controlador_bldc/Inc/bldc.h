#ifndef BLDC_H_
#define BLDC_H_

int set_step(uint32_t * step, uint32_t new_step);
void set_hold(uint32_t * delay, uint8_t new_delay);
int thr(uint32_t en, uint32_t *dcAtual, uint32_t * delay, uint32_t * step);
void help(void);
int check_in_with_value(char *entrada, char *func, uint32_t *val);
int check_in(char * entrada, char * func);

#endif /* BLDC_H_ */
