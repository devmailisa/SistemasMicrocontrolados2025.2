/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Teste da uart2
 *
 * Aluna: Isabelle de Souza Medeiros
 */
#include <stdio.h>
#include <stdint.h>
#include <systick.h>
#include <fpu.h>
#include <uart2.h>

#define baudRate 	115200
#define APB1CLK		16000000

int main(void)
{
	uart2RxTxIni(baudRate, APB1CLK);
	fpuEnable();

	char * entrada;
	printf("Qual eh o seu nome?\r\n");
	entrada = uart2ReadString();
	printf("Bem-vindo, %s!\r\n", entrada);
	if(uart2CompareString(entrada, "Isabelle")) printf("Você me criou!\r\n");
	while(1);
}
