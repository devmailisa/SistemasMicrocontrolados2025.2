/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Teste do ADC de leitura continua
 *
 * Aluna: Isabelle de Souza Medeiros
 */
#include <stdio.h>
#include <stdint.h>
#include <systick.h>
#include <fpu.h>
#include <uart2.h>
#include <pwm.h>
#include <adc_continuo.h>

#define baudRate 	115200
#define APB1CLK		16000000

int main(void)
{
	uart2RxTxIni(baudRate, APB1CLK);
	adcContinuoIni();
	adcContinuoStart(1);
	uint32_t leitura;
	while(1)
	{
		leitura = adcContinuoRead();
		printf("Valor lido: %ld\n\r", leitura);
		delayMs(1000);
	}
}
