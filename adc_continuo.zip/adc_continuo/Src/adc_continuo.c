/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Implementação de adc_continuo.c
 *
 * Aluna: Isabelle de Souza Medeiros
 */

#include <stm32f446xx.h>
#include <systick.h>
#include <stdint.h>

void adcContinuoIni(void)
{
	RCC->AHB1ENR |= (1U<<0);
	GPIOA->MODER |= (1U<<2) | (1U<<3);

	RCC->APB2ENR |= (1U<<8);
	ADC->CCR &= ~((1U<<16) | (1U<<17));
	ADC1->CR1 &= ~((1U<<24) | (1U<<25));
	ADC1->CR2 &= ~(1U<<11);
	ADC1->SQR1 &= ~((1U<<23) | (1U<<22) | (1U<<21) | (1U<<20));
	ADC1->CR2 |= (1U<<0);
	delayUs(2);
}

void adcContinuoStart(int canal)
{
	ADC1->CR2 |= (1U<<1); //Habilita a conversão contínua
	ADC1->SQR3 = 0;
	ADC1->SQR3 |= (canal<<0);
	ADC1->SR = 0;
	ADC1->CR2 |= (1U<<30);
}

uint32_t adcContinuoRead(void)
{
	while(!(ADC1->SR & (1U<<1)))
	{

	}

	return ADC1->DR;
}

void adcContinuoDisable(void)
{
	ADC1->CR2 &= ~(1U<<0);
}



