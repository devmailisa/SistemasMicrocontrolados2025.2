/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Implementação de adc_simples.c
 *
 * Aluna: Isabelle de Souza Medeiros
 */

#ifndef ADC_CONTINUO_H_
#define ADC_CONTINUO_H_


void adcContinuoIni(void);
void adcContinuoStart(int canal);
uint32_t adcContinuoRead(void);
void adcContinuoDisable(void);

#endif /* ADC_CONTINUO_H_ */
