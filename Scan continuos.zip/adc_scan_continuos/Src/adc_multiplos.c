#include "stm32f446xx.h"
#include <stdio.h>
#include <stdint.h>
#include <systick.h>
#include <adc_multiplos.h>

volatile uint16_t valores[numCh];
volatile uint8_t idx_adc = 0;

void adcIni(void) {
	__disable_irq();
   // Configuração do GPIO
   RCC->AHB1ENR |= (1U << 0);                         // Habilita clock para GPIOA (não necessário com USART)
   GPIOA->MODER |= (1U << 1) | (1U << 0);             // Pino PA0 como canal analógico
   GPIOA->MODER |= (1U << 3) | (1U << 2);             // Pino PA1 como canal analógico
   GPIOA->MODER |= (1U << 9) | (1U << 8);             // Pino PA4 como canal analógico
   RCC->APB2ENR |= (1U << 8);                         // Habilitando clock do ADC1
   ADC->CCR &= ~((1U << 16) | (1U << 17));            // Configurando P.S. para 2
   ADC1->CR1 &= ~((1U << 24) | (1U << 25));           // Configurando a resolução de 12 bits
   ADC1->CR2 &= ~(1U << 11);                          // Mantendo alinhamento à direita
   ADC1->SMPR2 |= (1U << 0)                           // SMP0 bit 0
                | (1U << 1)                           // SMP0 bit 1
                | (1U << 2)                           // SMP0 bit 2
                | (1U << 3)                           // SMP1 bit 0
                | (1U << 4)                           // SMP1 bit 1
                | (1U << 5)                           // SMP1 bit 2
                | (1U << 12)                          // SMP4 bit 0
                | (1U << 13)                          // SMP4 bit 1
                | (1U << 14);                         // SMP4 bit 2
   ADC1->CR1 |= (1U << 8) | (1U << 5);                // Bit SCAN = 1 – EOCIE (interrupção)
   ADC1->CR2 |= (1U << 1) | (1U << 10);               // Bit EOCS = 1 → EOC no fim de cada conversão regular
   ADC1->SQR1 &= ~((1U << 20) | (1U << 21) | (1U << 22) | (1U << 23));  // Limpeza dos bits de sequência
   ADC1->SQR1 |= (1U << 21);                          // Configurando para 3 leituras – 0010
   ADC1->SQR3 = (0U << 0) | (1U << 5) | (4U << 10);   // Sequência dos canais lidos
   NVIC_SetPriority(ADC_IRQn, 1);                     // Prioridade no NVIC
   NVIC_EnableIRQ(ADC_IRQn);                          // Habilita a interrupção do ADC1 no NVIC
   __enable_irq();
   ADC1->CR2 |= (1U << 0);                            // Habilita o ADC1
   delayUs(2);
}


void adcStart()
{
	ADC1->CR2 |= (1U << 30);
}

//Rotina de tratamento de interrupção
void ADC_IRQHandler(void)
{
	if(ADC1->SR & (1U << 1))
	{
		valores[idx_adc] = ADC1->DR;
		if (idx_adc >= numCh){
			idx_adc = 0;
		}
	}
}

