#include <stdint.h>
#include <adc_multiplos.h>
#include <stm32f446xx.h>
#include <uart2.h>
#include <systick.h>
#include <stdio.h>
#include <fpu.h>

#define baudRate   115200
#define APB1CLK   16000000

static const uint8_t canais[numCh] = { 0, 1, 4 };

int main(void) {
   uart2RxTxIni(baudRate , APB1CLK);
   fpuEnable();
   adcIni();
   adcStart();
   while (1) {
       printf("Leituras ADC (continuo, 0-1-4):\r\n");
       for (uint8_t i = 0; i < numCh; i++) {
           printf("Canal - %d = %d\r\n", canais[i], valores[i]);
       }
       printf("\r\n");
       delayMs(2000);
   }
}
