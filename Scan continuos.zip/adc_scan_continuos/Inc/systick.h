/*
 * systick.h
 *
 *  Created on: Nov 18, 2025
 *      Author: 20221610005
 */

#ifndef SYSTICK_H_
#define SYSTICK_H_

void delayMs(uint32_t delay);
void delayUs(uint32_t delay);

#endif /* SYSTICK_H_ */
