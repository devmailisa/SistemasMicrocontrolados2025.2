/*
 * fpu.h
 *
 *  Created on: Nov 18, 2025
 *      Author: 20221610005
 */

#ifndef FPU_H_
#define FPU_H_

void fpuEnable(void);

#endif /* FPU_H_ */
