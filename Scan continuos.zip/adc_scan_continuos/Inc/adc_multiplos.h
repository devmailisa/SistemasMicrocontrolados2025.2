
#ifndef ADC_MULTIPLOS_H_
#define ADC_MULTIPLOS_H_
#include <stdint.h>

#define numCh 3

extern volatile uint16_t valores[numCh];
extern volatile uint8_t idx_adc;

void adcIni(void);
void adcStart(void);
void ADC_IRQHandler(void);

#endif /* ADC_MULTIPLOS_H_ */
