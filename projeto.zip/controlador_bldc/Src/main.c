/*
 * CONTROLADOR DO MOTOR BLDC COM MCU STM32F446REX
*/

#include <stdint.h>
#include <stdio.h>

#include <bldc.h>
#include <fpu.h>
#include <uart2.h>
#include <timer2.h>

#define baudRate 	115200
#define clk			16000000

int main(void)
{
	configurarTimer2();
	calibrar_motor();

	fpuEnable();
	uart2RxTxIni(baudRate, clk);
	/*
	char * entrada;
	uint32_t val;
	uint32_t dcAtual = 53;
	uint32_t delay = 50;
	uint32_t step = 2;

	int activated = 0;*/

	while(1)
	{/*
		entrada = uart2ReadString();

		if(check_in_with_value(entrada, "THR ", &val))
		{
			//chama THR
			int err_thr = thr(val, &dcAtual, &delay, &step);
			if(!err_thr)
			{
				printf("ERR:ALVO DO THROTTLE FORA DO INTERVALO DE [0, 100]\r\n");
			} else
			{
				printf("THROTTLE AJUSTADO COM SUCESSO\r\n");
			}
		} else if (check_in_with_value(entrada, "SET STEP=", &val))
		{
			//chama SET STEP
			if(set_step(&step, val))
			{
				printf("STEP AJUSTADO COM SUCESSO\r\n");
			} else
			{
				printf("STEP FORA DO INTERVALO [1, 10]\r\n");
			}

		} else if (check_in_with_value(entrada, "SET HOLD=", &val))
		{
			set_hold(&delay, val);
			printf("HOLD AJUSTADO COM SUCESSO\r\n");
		} else if(check_in(entrada, "HELP"))
		{
			help();
		}else if(check_in(entrada, "ARM"))
		{
			if(activated){
				printf("O MOTOR JÁ ESTÁ FUNCIONANDO");
			}else{
				activated = 1;
				int err = thr(72, &dcAtual, &delay, &step);
				if(!err) printf("MOTOR ATIVO EM 30%%");
			}
		}else if(check_in(entrada, "DISARM"))
		{
			activated = 1;
			int err = thr(52, &dcAtual, &delay, &step);
			if(!err) printf("MOTOR DESATIVADO");
		}else{
			printf("COMANDO NÃO IDENTIFICADO\r\n");
		}*/
	}
}
