/*
 * timer2.h
 *
 *  Created on: Oct 21, 2025
 *      Author: 20221610005
 */

#ifndef TIMER2_H_
#define TIMER2_H_

void configurarTimer2(void);
void setDuty(uint32_t duty);

#endif /* TIMER2_H_ */
