
#ifndef ADC_MULTIPLOS_H_
#define ADC_MULTIPLOS_H_
#include <stdint.h>

void adcIni(void);
void adcReadCanais(uint16_t *buf, uint16_t numCanais);

#endif /* ADC_MULTIPLOS_H_ */
