#include "stm32f446xx.h"
#include <stdint.h>
#include <adc_multiplos.h>
#include <uart2.h>
#include <systick.h>
#include <stdio.h>
#include <fpu.h>

#define baudRate   115200
#define APB1CLK   16000000

#define numCh 3

static const uint8_t canais[numCh] = { 0, 1, 4 };
uint16_t valores[numCh];

int main(void) {
   uart2RxTxIni(baudRate , APB1CLK);
   fpuEnable();
   adcIni();
   while (1) {
	   adcReadCanais(valores, numCh);
       printf("Leituras ADC (0-1-4):\r\n");
       for (uint8_t i = 0; i < numCh; i++) {
           printf("Canal - %d = %d\r\n", canais[i], valores[i]);
       }
       printf("\r\n");
       delayMs(2000);
   }
}
