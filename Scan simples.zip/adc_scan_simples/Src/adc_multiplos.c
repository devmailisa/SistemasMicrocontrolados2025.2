#include "stm32f446xx.h"
#include <stdio.h>
#include <stdint.h>
#include <systick.h>
#include <adc_multiplos.h>

void adcIni(void) {
   // Configuração do GPIO
   RCC->AHB1ENR |= (1U << 0);                         // Habilita clock para GPIOA (não necessário com USART)
   GPIOA->MODER |= (1U << 1) | (1U << 0);             // Pino PA0 como canal analógico
   GPIOA->MODER |= (1U << 3) | (1U << 2);             // Pino PA1 como canal analógico
   GPIOA->MODER |= (1U << 9) | (1U << 8);             // Pino PA4 como canal analógico
   RCC->APB2ENR |= (1U << 8);                         // Habilitando clock do ADC1
   ADC->CCR &= ~((1U << 16) | (1U << 17));            // Configurando P.S. para 2
   ADC1->CR1 &= ~((1U << 24) | (1U << 25));           // Configurando a resolução de 12 bits
   ADC1->CR2 &= ~(1U << 11);                          // Mantendo alinhamento à direita
   ADC1->CR1 |= (1U << 8) | (1U<<10);                 // Bit SCAN = 1
   ADC1->CR2 &= ~(1U << 1);                           // Bit EOCS = 1 → EOC no fim de cada conversão regular
   ADC1->SQR1 &= ~((1U << 20) | (1U << 21) | (1U << 22) | (1U << 23));  // Limpeza dos bits de sequência
   ADC1->SQR1 |= (1U << 21);                          // Configurando para 3 leituras – 0010
   ADC1->SQR3 = (0U << 0) | (1U << 5) | (4U << 10);   // Sequência dos canais lidos                        // Habilita a interrupção do ADC1 no NVIC
   ADC1->CR2 |= (1U << 0);                            // Habilita o ADC1
   delayUs(2);
}

void adcReadCanais(uint16_t *buf, uint16_t numCanais)
{
	ADC1->CR2 |= (1U << 30);
	uint16_t i;
	for (i = 0; i < numCanais; i++){
		while(!(ADC1->SR & (1U<<1))){
			//Aguarda enquanto o bit EOC não recebe 1
		}
		buf[i] = ADC1->DR;
	}

}
