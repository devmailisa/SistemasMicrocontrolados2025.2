Src/main.o: ../Src/main.c ../Inc/systick.h ../Inc/fpu.h ../Inc/uart2.h \
 ../Inc/pwm.h ../Inc/adc_continuo.h ../Inc/adc1_in18.h
../Inc/systick.h:
../Inc/fpu.h:
../Inc/uart2.h:
../Inc/pwm.h:
../Inc/adc_continuo.h:
../Inc/adc1_in18.h:
