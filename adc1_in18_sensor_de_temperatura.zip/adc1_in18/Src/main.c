/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Teste da leitura continua do sensor de temperatura adc1_in18
 *
 * Aluna: Isabelle de Souza Medeiros
 */
#include <stdio.h>
#include <stdint.h>
#include <systick.h>
#include <fpu.h>
#include <uart2.h>
#include <pwm.h>
#include <adc_continuo.h>
#include <adc1_in18.h>

#define baudRate 	115200
#define APB1CLK		16000000

int main(void)
{
	uart2RxTxIni(baudRate, APB1CLK);
	adcContinuoIni();
	adcContinuoStart(1);
	uint32_t leitura;
	double tensao, temperatura;
	while(1)
	{
		leitura = adc1In18Read();
		tensao = (leitura*3.3)/(4095.0);
		temperatura = ((tensao-0.76)/0.025)+25;
		printf("Valor lido no conversor: %ld\n\r", leitura);
		printf("Valor convertido para tensao: %lf\n\r", tensao);
		printf("Valor convertido para temperatura: %lf\n\r", temperatura);
		delayMs(1000);
	}
}
