/*
 * adc1_in18.h
 */

#ifndef ADC1_IN18_H_
#define ADC1_IN18_H_

void adc1In18Ini(void);
void adc1In18Start(int canal);
uint32_t adc1In18Read(void);
void adc1In18Disable(void);

#endif /* ADC1_IN18_H_ */
