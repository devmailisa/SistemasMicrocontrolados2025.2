/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Teste da uart2
 *
 * Aluna: Isabelle de Souza Medeiros
 */
#include <stdio.h>
#include <stdint.h>
#include <systick.h>
#include <fpu.h>
#include <uart2.h>
#include <pwm.h>

#define baudRate 	115200
#define APB1CLK		16000000

int main(void)
{
	uart2RxTxIni(baudRate, APB1CLK);
	fpuEnable();
	configCenterAlignedMode1(1000, 160-1);
	setDuty(50);
	while(1);
}
