/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Implementação da biblioteca systick.c
 *
 * Aluna: Isabelle de Souza Medeiros
 */

#include <stm32f446xx.h>
#include <stdint.h>

#define SYST_CSR_ENABLE		(1<<0)
#define SYST_CSR_CLKSOURCE	(1<<2) //Determina que eh o clock interno do MCU
#define SYST_CSR_COUNTFLAG	(1<<16) //Flag que retorna 1 quando o valor de reload eh alcançado
#define SYST_CLK			16000000
#define BASE_VALUE			(SYST_CLK/1000) - 1

void delayMs(uint32_t delay)
{
	if(delay == 0) return;

	uint32_t reload = BASE_VALUE;
	if(reload > 0xFFFFFFUL) reload = 0xFFFFFFUL;

	SysTick->CTRL = 0U;
	SysTick->LOAD = reload;
	SysTick->VAL = 0U;
	SysTick->CTRL = SYST_CSR_CLKSOURCE | SYST_CSR_ENABLE;

	while(delay--){
		while((SysTick->CTRL & SYST_CSR_COUNTFLAG) == 0U);
	}

	SysTick->CTRL = 0U;
	SysTick->VAL = 0U;
}
