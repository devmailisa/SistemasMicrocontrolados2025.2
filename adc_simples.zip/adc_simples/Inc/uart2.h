/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Implementação da biblioteca uart2.h
 *
 * Aluna: Isabelle de Souza Medeiros
 */

#ifndef UART2_H_
#define UART2_H_

void uart2RxTxIni(uint32_t baudRate, uint32_t clkPerif);
void uart2Write(int ch);
char uart2Read(void);
char* uart2ReadString(void);
int uart2StringTam(char * str);
int uart2CompareString(char * str1, char * str2);
int __io_putchar (int ch);

#endif /* UART2_H_ */
