/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Implementação da biblioteca systick.h
 *
 * Aluna: Isabelle de Souza Medeiros
 */

#ifndef SYSTICK_H_
#define SYSTICK_H_

void delayMs(uint32_t delay);
void delayUs(uint32_t delay);

#endif /* SYSTICK_H_ */
