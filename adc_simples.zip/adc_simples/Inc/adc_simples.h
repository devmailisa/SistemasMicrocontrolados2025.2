/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Implementação de adc_simples.h
 *
 * Aluna: Isabelle de Souza Medeiros
 */

#ifndef ADC_SIMPLES_H_
#define ADC_SIMPLES_H_

void adcIni(void);
void adcStart(int canal);
uint32_t adcRead(void);
void adcDisable(void);

#endif /* ADC_SIMPLES_H_ */
