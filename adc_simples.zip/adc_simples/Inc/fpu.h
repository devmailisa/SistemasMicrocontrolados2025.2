/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Implementação da biblioteca uart2.h
 *
 * Aluna: Isabelle de Souza Medeiros
 */

#ifndef FPU_H_
#define FPU_H_

void fpuEnable(void);

#endif /* FPU_H_ */
