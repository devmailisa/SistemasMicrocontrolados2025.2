/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Teste da uart2
 *
 * Aluna: Isabelle de Souza Medeiros
 */

#include <stm32f446xx.h>

#define enableGPIOA	(1U<<0)
#define TIM2EN		(1U<<0)


void setDuty(uint32_t duty)
{
	TIM2->CCR1 = duty;
}



void configEdgeAlignedMode1(uint32_t C_MAX, uint32_t PSC)
{
	RCC->AHB1ENR |= enableGPIOA;

	//Configurando Moder PA0 e PA1 -> 10 (função alternativa)
	GPIOA->MODER |= (1U<<1) | (1U<<3);
	GPIOA->MODER &= ~((1U<<0) | (1U<<2));

	//Configurando AFRL PA0 e PA1 para AF1 -> 0001
	GPIOA->AFR[0] |= (1U<<0) | (1U<<4);
	GPIOA->AFR[0] &= ~(((1U<<1) | (1U<<2) | (1U<<3) | (1U<<5) | (1U<<6) | (1U<<7)));

	//Configurando Timer 2
	RCC->APB1ENR |= TIM2EN;
	TIM2->PSC = PSC; //Valor de prescale definido pela expressao [Fclk / Fpwm*(C_MAX + 1)] - 1
	TIM2->ARR = C_MAX; //Valor máximo de contagem calculado pela expressao (Vc / Dc)*100 - 1
	TIM2->CNT = 0; //Zera o valor do contador

	//Configurando o canal 1 para gerar um PWM de modo 1 (o período inicia com o semiciclo positivo)
	TIM2->CCMR1 |= (1U<<5) | (1U<<6);
	TIM2->CCMR1 &= ~(1U<<4);

	//Habilitando o canal 1
	TIM2->CCER |= (1U << 0);

	//Iniciando o Timer 2
	TIM2->CR1 |= (1U<<0);
}



void configCenterAlignedMode1(uint32_t C_MAX, uint32_t PSC)
{
	RCC->AHB1ENR |= enableGPIOA;

	//Configurando Moder PA0 e PA1 -> 10 (função alternativa)
	GPIOA->MODER |= (1U<<1) | (1U<<3);
	GPIOA->MODER &= ~((1U<<0) | (1U<<2));

	//Configurando AFRL PA0 e PA1 para AF1 -> 0001
	GPIOA->AFR[0] |= (1U<<0) | (1U<<4);
	GPIOA->AFR[0] &= ~(((1U<<1) | (1U<<2) | (1U<<3) | (1U<<5) | (1U<<6) | (1U<<7)));

	//Configurando Timer 2
	RCC->APB1ENR |= TIM2EN;
	TIM2->PSC = PSC; //Valor de prescale definido pela expressao [Fclk / Fpwm*(C_MAX + 1)] - 1
	TIM2->ARR = C_MAX; //Valor máximo de contagem calculado pela expressao (Vc / Dc)*100
	TIM2->CNT = 0; //Zera o valor do contador

	//Configurando o canal 1 para gerar um PWM de modo 1 (o período inicia com o semiciclo positivo)
	TIM2->CCMR1 |= (1U<<5) | (1U<<6);
	TIM2->CCMR1 &= ~(1U<<4);

	//Habilitando o modo Center Aligned
	TIM2->CR1 |= (1U<<5);

	//Habilitando o canal 1
	TIM2->CCER |= (1U << 0);

	//Iniciando o Timer 2
	TIM2->CR1 |= (1U<<0);
}
