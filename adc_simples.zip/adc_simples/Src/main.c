/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Teste da uart2
 *
 * Aluna: Isabelle de Souza Medeiros
 */
#include <stdio.h>
#include <stdint.h>
#include <systick.h>
#include <fpu.h>
#include <uart2.h>
#include <pwm.h>
#include <adc_simples.h>

#define baudRate 	115200
#define APB1CLK		16000000

int main(void)
{
	uart2RxTxIni(baudRate, APB1CLK);
	adcIni();
	adcStart(1);
	uint32_t leitura;
	while(1)
	{
		leitura = adcRead();
		printf("Valor lido: %ld\r\n", leitura);
		delayMs(1000);
	}
}
