/*
 * Disciplina de Sistemas Microcontrolados 2025.2
 * Implementação da biblioteca uart2.h
 *
 * Aluna: Isabelle de Souza Medeiros
 */

#include <stm32f446xx.h>

void fpuEnable(void)
{
	SCB->CPACR |= (1U<<20) | (1U<<21) | (1U<<22) | (1U<<23);
}
