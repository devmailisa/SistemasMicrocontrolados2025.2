//Teste do Timer. Autor: Thyago Vasconcelos. Data: 14/06/2025


#include <stm32f446xx.h>

#include <stdint.h>

#include <stdio.h>

#include <inttypes.h>

#include <uart2.h>

#include <configclock.h>


#ifndef HSI_VALUE

#define HSI_VALUE 16000000U

#endif


#ifndef HSE_VALUE

#define HSE_VALUE 8000000U

#endif



static inline uint32_t AHB_Div(uint32_t hpre)

{

static const uint16_t div[16] = {1,1,1,1,1,1,1,1, 2,4,8,16, 64,128,256,512};

return div[hpre & 0xF];

}


static inline uint32_t APB_Div(uint32_t ppre)

{

static const uint8_t div[8] = {1,1,1,1, 2,4,8,16};

return div[ppre & 0x7];

}



static const char* GetSYSCLK_SourceStr(void)

{

uint32_t sws = (RCC->CFGR >> RCC_CFGR_SWS_Pos) & 0x3U;

switch (sws) {

case 0U: return "HSI";

case 1U: return "HSE";

case 2U: return "PLL";

default: return "Desconhecida";

}

}



static inline uint32_t GetHSI_Hz(void) { return HSI_VALUE; }


static inline uint32_t GetHSE_Hz(void)

{

if ((RCC->CR & RCC_CR_HSEON) && (RCC->CR & RCC_CR_HSERDY)) return HSE_VALUE;

return 0U;

}


static inline int IsHSEBypass(void)

{

return (RCC->CR & RCC_CR_HSEBYP) ? 1 : 0;

}



static uint32_t GetSYSCLK_Hz(void)

{

uint32_t sws = (RCC->CFGR >> RCC_CFGR_SWS_Pos) & 0x3U;

if (sws == 0U) return GetHSI_Hz();

if (sws == 1U) return HSE_VALUE; // neste caso SYSCLK == HSE


uint32_t pllsrc_hz = (RCC->PLLCFGR & RCC_PLLCFGR_PLLSRC) ? HSE_VALUE : HSI_VALUE;

uint32_t pllm = (RCC->PLLCFGR & 0x3FU);

uint32_t plln = (RCC->PLLCFGR >> 6) & 0x1FFU;

uint32_t pllp_sel = (RCC->PLLCFGR >> 16) & 0x3U; // 00=>/2, 01=>/4, 10=>/6, 11=>/8

uint32_t pllp = (pllp_sel + 1U) * 2U;


uint64_t vco = ((uint64_t)pllsrc_hz * (uint64_t)plln) / (uint64_t)pllm;

return (uint32_t)(vco / pllp);

}



static uint32_t GetHCLK_Hz(void)

{

uint32_t hpre = (RCC->CFGR >> 4) & 0xFU;

return GetSYSCLK_Hz() / AHB_Div(hpre);

}


static uint32_t GetPCLK1_Hz(void)

{

uint32_t ppre1 = (RCC->CFGR >> 10) & 0x7U;

return GetHCLK_Hz() / APB_Div(ppre1);

}


static uint32_t GetPCLK2_Hz(void)

{

uint32_t ppre2 = (RCC->CFGR >> 13) & 0x7U;

return GetHCLK_Hz() / APB_Div(ppre2);

}



static uint32_t GetTIMxCLK_FromPCLK(uint32_t pclk, uint32_t ppre_code)

{

return (APB_Div(ppre_code) == 1U) ? pclk : (pclk * 2U);

}


static uint32_t GetTIM1CLK_Hz(void) // APB2 timers: TIM1/TIM8/9/10/11

{

uint32_t ppre2 = (RCC->CFGR >> 13) & 0x7U;

return GetTIMxCLK_FromPCLK(GetPCLK2_Hz(), ppre2);

}


static uint32_t GetTIM2CLK_Hz(void) // APB1 timers: TIM2/3/4/5/6/7/12/13/14

{

uint32_t ppre1 = (RCC->CFGR >> 10) & 0x7U;

return GetTIMxCLK_FromPCLK(GetPCLK1_Hz(), ppre1);

}



void PrintClocks(void)

{

uint32_t hse = GetHSE_Hz();

uint32_t sys = GetSYSCLK_Hz();

uint32_t hclk = GetHCLK_Hz();

uint32_t pclk1 = GetPCLK1_Hz();

uint32_t pclk2 = GetPCLK2_Hz();

uint32_t tim1 = GetTIM1CLK_Hz();

uint32_t tim2 = GetTIM2CLK_Hz();


printf("HSE: %" PRIu32 " Hz (%s)\r\n", hse, IsHSEBypass() ? "bypass" : "oscillator");

printf("HSI: %" PRIu32 " Hz\r\n", GetHSI_Hz());

printf("SYSCLK: %" PRIu32 " Hz [fonte: %s]\r\n", sys, GetSYSCLK_SourceStr());

printf("HCLK: %" PRIu32 " Hz\r\n", hclk);

printf("PCLK1: %" PRIu32 " Hz\r\n", pclk1);

printf("PCLK2: %" PRIu32 " Hz\r\n", pclk2);

printf("TIM1CLK: %" PRIu32 " Hz\r\n", tim1);

printf("TIM2CLK: %" PRIu32 " Hz\r\n", tim2);

}


int main(void)

{

clockConfig();

//uart2RxTxIni(115200, 16000000); // OBS: ajuste para o clock real do USART2 (PCLK1) quando mudar o PLL!
uart2RxTxIni(115200, 45000000);
PrintClocks();

while (1) {}

}
