Src/main.o: ../Src/main.c \
 Z:/20221610005/Downloads/CMSIS/Device/ST/STM32F4xx/Include/stm32f446xx.h \
 Z:/20221610005/Downloads/CMSIS/Include/core_cm4.h \
 Z:/20221610005/Downloads/CMSIS/Include/cmsis_version.h \
 Z:/20221610005/Downloads/CMSIS/Include/cmsis_compiler.h \
 Z:/20221610005/Downloads/CMSIS/Include/cmsis_gcc.h \
 Z:/20221610005/Downloads/CMSIS/Include/mpu_armv7.h \
 Z:/20221610005/Downloads/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h \
 ../Inc/uart2.h ../Inc/timer2.h ../Inc/clock.h ../Inc/intext.h
Z:/20221610005/Downloads/CMSIS/Device/ST/STM32F4xx/Include/stm32f446xx.h:
Z:/20221610005/Downloads/CMSIS/Include/core_cm4.h:
Z:/20221610005/Downloads/CMSIS/Include/cmsis_version.h:
Z:/20221610005/Downloads/CMSIS/Include/cmsis_compiler.h:
Z:/20221610005/Downloads/CMSIS/Include/cmsis_gcc.h:
Z:/20221610005/Downloads/CMSIS/Include/mpu_armv7.h:
Z:/20221610005/Downloads/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h:
../Inc/uart2.h:
../Inc/timer2.h:
../Inc/clock.h:
../Inc/intext.h:
