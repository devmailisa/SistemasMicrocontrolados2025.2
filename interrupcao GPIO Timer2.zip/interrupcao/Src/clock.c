#include "stm32f446xx.h"

#define LATENCY (5U<<0)
#define PREFTEN (1U<<8)
#define ICEN 	(1U<<9)
#define DCEN 	(1U<<10)
#define PWREN 	(1U<<28)
#define ODEN 	(1U<<16)
#define ODSWEN 	(1U<<17)
#define ODRDY 	(1U<<16)
#define ODSWRDY (1U<<17)
#define HSEON 	(1U<<16)
#define HSERDY 	(1U<<17)
#define HSEBYP 	(1U<<18)
#define PLLM 		4U
#define PLLN 		180U
#define PLLP 		0U
#define PLLSRC 		(1U<<22)
#define PLLM_MSK 	(0x3FU<<0)
#define PLLN_MSK 	(0x1FFU<<6)
#define PLLP_MSK 	(0x3FU<<16)
#define PLLSRC_MSK 	(1U<<22)
#define HPREDIV1 	(0U<<4)
#define PPRE1DIV4 	(5U<<10)
#define PPRE2DIV2 	(4U<<13)
#define PLLON	 	(1U<<24)
#define PLLRDY	 	(1U<<25)

void clockConfig(void)
{
	FLASH-> ACR |= LATENCY | PREFTEN | ICEN | DCEN;
	RCC->APB1ENR |= PWREN;
	PWR->CR |= ODEN;
	while(!(PWR->CSR & ODRDY));
	PWR->CR |= ODSWEN;
	while(!(PWR->CSR & ODSWRDY));
	RCC->CR |= HSEBYP;
	RCC->CR |= HSEON;
	while(!(RCC->CR & HSERDY));
	RCC->CFGR |= (HPREDIV1 | PPRE1DIV4 | PPRE2DIV2);
	RCC->PLLCFGR &= ~(PLLM_MSK | PLLN_MSK | PLLP_MSK | PLLSRC_MSK);
	RCC->PLLCFGR |= (PLLM<<0) | (PLLN<<6) | (PLLP<<16) | PLLSRC;
	RCC->CR |= PLLON;
	while(!(RCC->CR & PLLRDY));
	RCC->CFGR |= (2<<0);
	while(!(RCC->CFGR & (2<<2)));
}
