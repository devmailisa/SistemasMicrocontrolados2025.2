#include "stm32f446xx.h"
#define enableGPIOA (1U<<0)
#define UG			(1U<<0)

void setDuty(uint8_t duty){
	TIM5->CCR1 = duty;
}

void configurarPWM(){
	RCC->AHB1ENR |= enableGPIOA; //Habilitando o clock para GPIOA
	//Modo alternativo de funcionamento dos pinos PA0 e PA1
	GPIOA->MODER &= ~(1U << 0); //Configuração como saída do pino PA0  Moder0: (10) - Modo alternativo
	GPIOA->MODER |= (1U << 1);  //Configuração como saída do pino PA0  Moder0: (10) - Modo alternativo
	//Configurando a função alternativa do pino (Acessando os bits referentes aos pinos PA0 e escrevedo 0001)
	GPIOA->AFR[0] |= (1U << 0);
	GPIOA->AFR[0] &= ~(1U << 1);
	GPIOA->AFR[0] &= ~(1U << 2);
	GPIOA->AFR[0] &= ~(1U << 3);
	//Configurar o Timer 2
	RCC->APB1ENR |= (1U<<0); //habilitando o clock para o timer2
	TIM2->PSC = 80-1; //Valor calculado do P.S.
	TIM2->ARR = 100; //Valor calculado para o ARR (valor máximo da contagem)
	TIM2->EGR  |= UG;
	TIM2->CNT = 0; //Zera o valor do contador do timer para operação correta.
	//Configurando o canal 1 - 110 - Modo 1 do PWM
	TIM2->CCMR1 |= (1U << 6);
	TIM2->CCMR1 |= (1U << 5);
	TIM2->CCMR1 &= ~(1U << 4);
	//Habilitando o canal 1
	TIM2->CCER |= (1U << 0);
	//Ajustando para o modo center-aligned
	TIM2->CR1 |= (1<<5);
	//Habilitando o Timer
	TIM2->CR1 |= (1U<<0);
}

