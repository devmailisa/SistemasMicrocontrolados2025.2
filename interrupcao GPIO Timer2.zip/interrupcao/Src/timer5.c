#include <stdint.h>

#include "stm32f446xx.h"
#include <systick.h>
#define enableGPIOA (1U<<0)
#define TIM5EN		(1U<<3)
#define APB1CLK		16000000
#define UG			(1U<<0)
#define UIF			(1U<<0)
#define CEN			(1U<<0)
#define URS			(1U<<2)

void pa1InputCapture(void){
	RCC->AHB1ENR |= enableGPIOA;
	GPIOA->MODER |= (1U<<3);
	GPIOA->MODER &= ~(1U<<2);
	GPIOA->AFR[0] |= (1U<<5);

	RCC->APB1ENR |= TIM5EN;
	TIM5->PSC = 16 - 1;
	TIM5->EGR |= UG;
	TIM5->CCMR1 |=(1U<<8);
	TIM5->CCER |= (1U<<4);
	TIM5->CR1 |= (1U<<0);
}
