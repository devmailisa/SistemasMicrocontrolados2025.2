#include <stm32f446xx.h>
#include <stdint.h>
#include <stdio.h>
#include <uart2.h>
#include <timer2.h>
#include <clock.h>
#include <intext.h>

#define baudRate 115200
#define APB1CLK 16000000

int main(void)
{
	uart2RxTxIni(115200, APB1CLK); // OBS: ajuste para o clock real do USART2 (PCLK1) quando mudar o PLL!
	tim2Interrupt();

	while (1) {

	}
}

void EXTI15_10_IRQHandler(void)
{
	if(EXTI->PR && (1U<<13))
	{
		EXTI->PR |= (1U<<13);
		printf("PC13 acionado. Interrupcao ok \n\r");

	}
}

void TIM2_IRQHandler(void)
{
	TIM2->SR &= ~UIF;
	printf("Tim2 acionado. Interrupcao ok \n\r");
}
