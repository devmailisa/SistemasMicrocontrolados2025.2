//IMPLEMENTAÇÃO DE DELAY

#include <stdint.h>

#include "stm32f446xx.h"
#include <systick.h>
#define enableGPIOA (1U<<0)
#define TIM2EN		(1U<<0)
#define APB1CLK		90000000
#define PSC_VALUE_S	1600
#define ARR_VALUE_MS 1000
#define ARR_VALUE_US 2
#define UG			(1U<<0)
#define UIF			(1U<<0)
#define CEN			(1U<<0)
#define URS			(1U<<2)

void delayMsTim2(uint32_t delay){
	if(delay == 0U){
		return;
	}

	RCC->APB1ENR |= TIM2EN;
	TIM2->CR1 = 0;
	TIM2->SR = 0;
	TIM2->PSC = APB1CLK/1000000;
	TIM2->ARR = (1000U*delay) - 1U;
	TIM2->CR1 |= URS;
	TIM2->EGR |= UG;
	TIM2->CNT = 0;
	TIM2->CR1 |= CEN;

	while(!(TIM2->SR & UIF)){

	}

	TIM2->SR = 0;
	TIM2->CR1 = 0;
}

void delayUsTim2(uint32_t delay){
	if(delay == 0U){
		return;
	}

	RCC->APB1ENR |= TIM2EN;
	TIM2->CR1 = 0;
	TIM2->SR = 0;
	TIM2->PSC = (APB1CLK/1000000U) - 1U;
	TIM2->ARR = delay - 1U;
	TIM2->CR1 |= URS;
	TIM2->EGR |= UG;
	TIM2->CNT = 0;
	TIM2->CR1 |= CEN;

	while(!(TIM2->SR & UIF)){

	}

	TIM2->SR = 0;
	TIM2->CR1 = 0;
}

void tim2Interrupt(void)
{
	__disable_irq();
	RCC->APB1ENR |= TIM2EN;

	TIM2->PSC = PSC_VALUE_S - 1U;
	TIM2->ARR = ARR_VALUE_MS - 1U;
	TIM2->CR1 |= URS;
	TIM2->EGR |= UG;

	TIM2->CNT = 0;
	TIM2->SR = 0;

	TIM2->DIER |= UIF;
	NVIC_SetPriority(TIM2_IRQn, 5);
	NVIC_EnableIRQ(TIM2_IRQn);

	TIM2->CR1 |= CEN;

	__enable_irq();

}

