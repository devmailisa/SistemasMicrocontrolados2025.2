#include "stm32f446xx.h"
#include <intext.h>

#define enableGPIOC (1U<<2)
#define SYSCFGEN	(1U<<14)

void intPC13(void)
{
	__disable_irq();

	RCC->AHB1ENR |= enableGPIOC;
	GPIOC->MODER &= ~((1U<<26) | (1U<<27));

	RCC->APB2ENR |= SYSCFGEN;
	SYSCFG->EXTICR[3] |= (1U<<5);
	EXTI->IMR |= (1U<<13);
	EXTI->FTSR |= (1U<<13);
	EXTI->PR |= (1U<<13);
	NVIC_SetPriority(EXTI15_10_IRQn, 5);
	NVIC_EnableIRQ(EXTI15_10_IRQn);

	__enable_irq();
}
