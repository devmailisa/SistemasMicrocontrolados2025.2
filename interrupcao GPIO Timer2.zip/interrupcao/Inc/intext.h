#ifndef INTEXT_H_
#define INTEXT_H_

void intPC13(void);

#endif /* INTEXT_H_ */
