

#ifndef TIMER2_H_
#define TIMER2_H_

void delayMsTim2(uint32_t delay);
void delayUsTim2(uint32_t delay);
void tim2Interrupt(void);

#define UIF (1U<<0)

#endif /* TIMER2_H_ */
