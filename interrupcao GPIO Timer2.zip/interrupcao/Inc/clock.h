/*
 * clock.h
 *
 *  Created on: Dec 2, 2025
 *      Author: 20221610005
 */

#ifndef CLOCK_H_
#define CLOCK_H_

void clockConfig(void);

#endif /* CLOCK_H_ */
