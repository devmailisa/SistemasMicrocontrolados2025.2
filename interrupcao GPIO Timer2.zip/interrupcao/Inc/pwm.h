/*
 * pwm.h
 *
 *  Created on: Dec 2, 2025
 *      Author: 20221610005
 */

#ifndef PWM_H_
#define PWM_H_

void configurarPWM();

#endif /* PWM_H_ */
