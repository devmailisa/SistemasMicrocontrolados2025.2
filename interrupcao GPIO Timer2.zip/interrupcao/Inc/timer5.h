/*
 * timer5.h
 *
 *  Created on: Nov 27, 2025
 *      Author: 20221610005
 */

#ifndef TIMER5_H_
#define TIMER5_H_

#define CC2IF (1U<<2)

void pa1InputCapture(void);
#endif /* TIMER5_H_ */
