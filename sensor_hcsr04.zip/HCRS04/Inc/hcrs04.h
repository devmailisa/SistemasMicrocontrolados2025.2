/*
 * hcrs04.h
 *
 *  Created on: Jan 18, 2026
 *      Author: Isabelle
 */

#ifndef HCRS04_H_
#define HCRS04_H_

void pa1InputCapture(void);
float medeDistanciaMediana(void);

#endif /* HCRS04_H_ */
