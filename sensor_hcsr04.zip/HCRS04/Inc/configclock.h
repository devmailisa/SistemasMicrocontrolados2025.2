/*
 * configclock.h
 *
 *  Created on: Jan 18, 2026
 *      Author: Isabelle
 */

#ifndef CONFIGCLOCK_H_
#define CONFIGCLOCK_H_

void clockConfig(void);

#endif /* CONFIGCLOCK_H_ */
