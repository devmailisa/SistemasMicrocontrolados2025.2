
#ifndef PWM_H_
#define PWM_H_

void setDuty(uint32_t duty);
void configEdgeAlignedMode1(uint32_t C_MAX, uint32_t PSC);
void configCenterAlignedMode1(uint32_t C_MAX, uint32_t PSC);

#endif /* PWM_H_ */
