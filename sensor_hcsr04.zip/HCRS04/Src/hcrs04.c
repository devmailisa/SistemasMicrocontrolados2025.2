/* Disciplina: Sistemas Microcontrolados
 * Sensor ultrassônico
 * hcrs04.c
 * Aluna: Isabelle Medeiros
 */

#include <stm32f446xx.h>
#include <stdint.h>
#include <systick.h>
#define APB1CLK			16000000
#define TIMER2EN		(1U<<0)
#define TIMER5EN		(1U<<3)
#define UG				(1U<<0)
#define CEN				(1U<<0)
#define enableGPIOA		(1U<<0)
#define pinoTrigger		(1U<<0)
#define CC2IF			(1U<<2)
#define N_AMOSTRAS		5
#define DIST_MIN_CM		4.0f
#define DIST_MAX_CM		400.0f



void pa1InputCapture(void){

	//GPIOA
	RCC->AHB1ENR |= enableGPIOA;
	GPIOA->MODER |= (1U<<3);
	GPIOA->MODER &= ~(1U<<2);
	GPIOA->AFR[0] |= (1U<<5);

	//Configurando o pino de Trigger
	GPIOA->MODER |= (1U<<0);
	GPIOA->MODER &= ~(1U<<1);
	GPIOA->ODR &= ~(1U<<0);

	//Timer 5
	RCC->APB1ENR |= TIMER5EN;
	TIM5->CR1 |= (1U<<0);
	TIM5->PSC = 16 - 1; //base da ordem de us
	TIM5->EGR |= UG;
	TIM5->CCMR1 |= (1U<<8); //Canal 2 mapeado na entrada 2
	TIM5->CCER |= (1U<<4); //CC2E=1 (enable)
	TIM2->CR1 |= (1U<<0); //habilita o contador
}

void disparaTrigger(void){
	GPIOA->ODR |= (1U<<0);
	delayUs(10);
	GPIOA->ODR &= ~(1U<<0);
}

float medeDistancia(void){
	//t1->tempo da borda de subida
	//t2->tempo da borda de descida
	//intervalo->largura do pulso ECHO (em contagens do timer)
	uint32_t t1, t2, intervalo;
	uint32_t timeout; //tempo de segurança para evitar loop

	//Garante o contador rodando
	TIM5->CR1 |= (1U<<0);
	//Borda de subida -> início do ECHO
	TIM5->CCER &= ~((1U<<5) | (1U<<7));
	//Limpa flag CC2IF -> flag que indica que uma captura ocorreu
	TIM5->SR &= ~CC2IF;
	//Espera subida com timeout
	timeout = 60000;
	while(!(TIM5->SR & CC2IF) && --timeout);
	if(timeout == 0){
		return -1.0f;
	}
	t1 = TIM5->CCR2;
	//Configurar borda de descida (fim do ECHO)
	TIM5->CCER |= (1U<<5);
	TIM5->CCER &= ~(1U<<7);
	//Limpa flag CC2IF de novo
	TIM5->SR &= ~CC2IF;
	timeout = 60000;
	while(!(TIM5->SR & CC2IF) && --timeout);
	if(timeout == 0){
		//Volta para rising edge - borda de subida - p/ proxima leitura
		TIM5->CCER &= ~(1U<<5);
		return -1.0f;
	}
	t2 = TIM5->CCR2;

	//Volta para rising edge - borda de subida - p/ proxima leitura
	TIM5->CCER &= ~(1U<<5);
	if(t2 >= t1) intervalo = t2-t1;
	else intervalo = (0xFFFFFFFFu - t1 + 1u + t2);

	//Calculando a distancia em cm
	float d = intervalo / 58.0f;
	return d;
}

static void ordenaFloat(float *v, int n){
	for (int i = 0; i < n-1; i++){
		for(int j = i+1; j < n; j++){
			if(v[j]<v[i]){
				float tmp = v[i];
				v[i] = v[j];
				v[j] = tmp;
			}
		}
	}
}

float medeDistanciaMediana(void){
	float medidas[N_AMOSTRAS];
	int nValidas = 0;
	for(int i = 0; i < N_AMOSTRAS;i++){
		disparaTrigger();
		float d = medeDistancia();
		if(d > DIST_MIN_CM && d < DIST_MAX_CM){
			medidas[nValidas++] = d;
		}
		delayMs(60);
	}
	if(nValidas == 0){
		return -1.0f;
	}
	ordenaFloat(medidas, nValidas);
	return medidas[nValidas/2]; //mediana
}
