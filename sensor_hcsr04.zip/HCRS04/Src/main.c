//Teste do sensor HC-SR04


#include <stm32f446xx.h>
#include <fpu.h>
#include <stdio.h>
#include <uart2.h>
#include <systick.h>
#include <hcrs04.h>

#define baudRate 	115200
#define APB1CLK		16000000
float dist = 0;

int main(void)
{
	uart2RxTxIni(baudRate, APB1CLK);
	fpuEnable();
	while(1){
		dist = medeDistanciaMediana();
		printf("\r\nDistancia: %.1f cm", dist);
		delayMs(1000);
	}

}
