/* Disciplina: Sistemas Microcontrolados
 * Timer 2 - Timer de uso geral
 * timer2.c
 * Aluna: Isabelle Medeiros
 */

#include <stm32f446xx.h>
#include <stdint.h>

#define APB1CLK			16000000
#define TIMER2EN		(1U<<0)
#define ARR_VALUE_MS	1000
#define ARR_VALUE_US	2
#define UG				(1U<<0)
#define UIF				(1U<<0)
#define CEN				(1U<<0)
#define URS				(1U<<2)

//Se o PSC do APB (PPRE1 ou PPRE2 no registrador RCC_CFGR)
//estiver configurado com fator de divisão igual a 1, então
//TIMxCLK = PCLKx, senão, a freq. do clock dos temporizadores
//é ajustada para o dobro da frequencua do APB ao qual
//estao conectados TIMxCLK = 2*PCLKx
#define TIM2CLK			90000000

void delayMsTim2(uint32_t delay){
	if(delay==0U){
		return;
	}

	RCC->APB1ENR |= TIMER2EN;
	TIM2->CR1 = 0;
	TIM2->CR2 = 0;
	TIM2->PSC = (TIM2CLK/1000000U);
	TIM2->ARR = (1000U*delay) - 1U;
	TIM2->CR1 |= URS;
	TIM2->EGR |= UG;
	TIM2->CNT = 0;
	TIM2->CR1 |= CEN;
	while(!(TIM2->SR & UIF)){

	}
	TIM2->SR = 0;
	TIM2->CR1 = 0;
}


void delayUsTim2(uint32_t delay){
	if(delay==0U){
		return;
	}

	RCC->APB1ENR |= TIMER2EN;
	TIM2->CR1 = 0;
	TIM2->CR2 = 0;
	TIM2->PSC = (APB1CLK/1000000U) - 1U;
	TIM2->ARR = delay - 1U;
	TIM2->CR1 |= URS;
	TIM2->EGR |= UG;
	TIM2->CNT = 0;
	TIM2->CR1 |= CEN;
	while(!(TIM2->SR & UIF)){

	}
	TIM2->SR = 0;
	TIM2->CR1 = 0;
}
