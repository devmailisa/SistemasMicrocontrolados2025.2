################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/adc_multiplos.c \
../Src/configclock.c \
../Src/fpu.c \
../Src/hcrs04.c \
../Src/main.c \
../Src/pwm.c \
../Src/syscalls.c \
../Src/sysmem.c \
../Src/systick.c \
../Src/timer2.c \
../Src/uart2.c 

OBJS += \
./Src/adc_multiplos.o \
./Src/configclock.o \
./Src/fpu.o \
./Src/hcrs04.o \
./Src/main.o \
./Src/pwm.o \
./Src/syscalls.o \
./Src/sysmem.o \
./Src/systick.o \
./Src/timer2.o \
./Src/uart2.o 

C_DEPS += \
./Src/adc_multiplos.d \
./Src/configclock.d \
./Src/fpu.d \
./Src/hcrs04.d \
./Src/main.d \
./Src/pwm.d \
./Src/syscalls.d \
./Src/sysmem.d \
./Src/systick.d \
./Src/timer2.d \
./Src/uart2.d 


# Each subdirectory must supply rules for building sources it contributes
Src/adc_multiplos.o: ../Src/adc_multiplos.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F446RETx -c -I../Inc -I"C:/Users/Isabelle/Downloads/CMSIS-20251019T024516Z-1-001/CMSIS/Include" -I"C:/Users/Isabelle/Downloads/CMSIS-20251019T024516Z-1-001/CMSIS/Device/ST/STM32F4xx/Include" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F446RETx -c -I../Inc -I"C:/Users/Isabelle/Downloads/CMSIS-20251019T024516Z-1-001/CMSIS/Device/ST/STM32F4xx/Include" -I"C:/Users/Isabelle/Downloads/CMSIS-20251019T024516Z-1-001/CMSIS/Include" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/adc_multiplos.cyclo ./Src/adc_multiplos.d ./Src/adc_multiplos.o ./Src/adc_multiplos.su ./Src/configclock.cyclo ./Src/configclock.d ./Src/configclock.o ./Src/configclock.su ./Src/fpu.cyclo ./Src/fpu.d ./Src/fpu.o ./Src/fpu.su ./Src/hcrs04.cyclo ./Src/hcrs04.d ./Src/hcrs04.o ./Src/hcrs04.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/pwm.cyclo ./Src/pwm.d ./Src/pwm.o ./Src/pwm.su ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su ./Src/systick.cyclo ./Src/systick.d ./Src/systick.o ./Src/systick.su ./Src/timer2.cyclo ./Src/timer2.d ./Src/timer2.o ./Src/timer2.su ./Src/uart2.cyclo ./Src/uart2.d ./Src/uart2.o ./Src/uart2.su

.PHONY: clean-Src

