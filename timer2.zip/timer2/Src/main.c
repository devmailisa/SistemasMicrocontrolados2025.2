#include "stm32f446xx.h"
#include <stdint.h>
#include <uart2.h>
#include <stdio.h>
#include <fpu.h>
#include <timer2.h>
#define baudRate   115200
#define APB1CLK   16000000

int main(void) {
   uart2RxTxIni(baudRate , APB1CLK);
   fpuEnable();
   while (1) {
	   delayMsTim2(1000); //delayUsTim2(1000000);
	   printf("Um segundo (1000 ms ou 1000000 us) se passou!");
   }
}
