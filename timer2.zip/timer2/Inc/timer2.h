

#ifndef TIMER2_H_
#define TIMER2_H_

void delayMsTim2(uint32_t delay);
void delayUsTim2(uint32_t delay);

#endif /* TIMER2_H_ */
